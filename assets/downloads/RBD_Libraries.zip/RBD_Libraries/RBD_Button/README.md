#Arduino Button Library v1.0.1
Read and debounce buttons and switches without delay.

* [Documentation](http://robotsbigdata.com/docs-arduino-button.html)
* [Download Library](https://github.com/alextaujenis/RBD_Button/raw/master/extras/RBD_Button.zip)
* [Project Website](http://robotsbigdata.com)
* [Report an Issue](https://github.com/alextaujenis/RBD_Button/issues/new)*

\**Please include your Arduino make/model and IDE version when reporting an issue with this library.*

#License
This code is available under the [MIT License](http://opensource.org/licenses/mit-license.php).