#Arduino Light Sensor Library v1.0.3
Read and calibrate photoresistors.

* [Documentation](http://robotsbigdata.com/docs-arduino-light-sensor.html)
* [Project Website](http://robotsbigdata.com)
* [Release Notes](https://github.com/alextaujenis/RBD_LightSensor/releases)
* [Comments, Questions, or Issues](https://github.com/alextaujenis/RBD_LightSensor/issues/new)*

\**Please include your Arduino make/model and IDE version when reporting an issue with this library.*

#License
This code is available under the [MIT License](http://opensource.org/licenses/mit-license.php).