#Arduino Relay Library v1.0.0 [![Build Passing](https://raw.githubusercontent.com/alextaujenis/RobotsBigData/gh-pages/src/images/passing.png)](https://github.com/alextaujenis/RBD_Relay/blob/master/extras/unit_test/unit_test.ino)
Control many relays without interrupts or delay.

* [Release Notes](https://github.com/alextaujenis/RBD_Relay/releases)
* [Comments, Questions, or Issues](https://github.com/alextaujenis/RBD_Relay/issues/new)*

\**Please include your Arduino make/model and IDE version when reporting an issue with this library.*

#License
This code is available under the [MIT License](http://opensource.org/licenses/mit-license.php).