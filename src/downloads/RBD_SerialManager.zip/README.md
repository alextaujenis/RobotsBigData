#Arduino Serial Manager Library v1.0.0-alpha.3
A simple interface for serial communication.

* [Documentation](http://robotsbigdata.com/docs-arduino-serial-manager.html)
* [Project Website](http://robotsbigdata.com)
* [Release Notes](https://github.com/alextaujenis/RBD_SerialManager/releases)
* [Comments, Questions, or Issues](https://github.com/alextaujenis/RBD_SerialManager/issues/new)*

\**Please include your Arduino make/model and IDE version when reporting an issue with this library.*

#License
This code is available under the [MIT License](http://opensource.org/licenses/mit-license.php).