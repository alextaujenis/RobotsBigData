#Arduino Motor Library v2.1.1
Control many motors without delay with commands like on(), off(), forward(), reverse(), and ramp().

* [Documentation](http://robotsbigdata.com/docs-arduino-motor.html)
* [Project Website](http://robotsbigdata.com)
* [Comments, Questions, or Issues](https://github.com/alextaujenis/RBD_Motor/issues/new)*

\**Please include your Arduino make/model and IDE version when reporting an issue with this library.*

#License
This code is available under the [MIT License](http://opensource.org/licenses/mit-license.php).